"""
GitLab MCP Python Server Configuration
"""
import os
from typing import Optional, List
from pydantic import BaseSettings, Field
from pydantic_settings import BaseSettings as PydanticBaseSettings

class GitLabConfig(PydanticBaseSettings):
    """Configuración del servidor GitLab MCP"""

    # Configuración básica de GitLab
    personal_access_token: str = Field(..., env="GITLAB_PERSONAL_ACCESS_TOKEN")
    api_url: str = Field("https://gitlab.com/api/v4", env="GITLAB_API_URL")

    # Configuración de proyectos
    project_id: Optional[str] = Field(None, env="GITLAB_PROJECT_ID")
    allowed_project_ids: Optional[str] = Field(None, env="GITLAB_ALLOWED_PROJECT_IDS")

    # Configuración de funcionalidades
    read_only_mode: bool = Field(False, env="GITLAB_READ_ONLY_MODE")
    use_gitlab_wiki: bool = Field(False, env="USE_GITLAB_WIKI")
    use_milestone: bool = Field(False, env="USE_MILESTONE")
    use_pipeline: bool = Field(False, env="USE_PIPELINE")

    # Configuración de autenticación
    auth_cookie_path: Optional[str] = Field(None, env="GITLAB_AUTH_COOKIE_PATH")

    # Configuración de proxy
    http_proxy: Optional[str] = Field(None, env="HTTP_PROXY")
    https_proxy: Optional[str] = Field(None, env="HTTPS_PROXY")

    # Configuración de logging
    log_level: str = Field("INFO", env="LOG_LEVEL")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

    def get_allowed_project_ids(self) -> List[str]:
        """Obtiene la lista de IDs de proyecto permitidos"""
        if not self.allowed_project_ids:
            return []
        return [pid.strip() for pid in self.allowed_project_ids.split(",") if pid.strip()]

    def is_project_allowed(self, project_id: str) -> bool:
        """Verifica si un proyecto está permitido"""
        allowed_ids = self.get_allowed_project_ids()
        if not allowed_ids:
            return True  # Si no hay restricciones, permitir todos
        return project_id in allowed_ids

# Instancia global de configuración
config = GitLabConfig()
