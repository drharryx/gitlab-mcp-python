#!/bin/bash

# GitLab MCP Python Server - Setup Script
# Este script automatiza la instalación y configuración inicial

set -e  # Exit on any error

echo "🚀 GitLab MCP Python Server - Setup"
echo "=================================="

# Verificar Python version
echo "📋 Verificando requisitos..."
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1-2)
REQUIRED_VERSION="3.9"

if ! python3 -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)" 2>/dev/null; then
    echo "❌ Error: Python 3.9+ requerido. Versión actual: $PYTHON_VERSION"
    exit 1
fi

echo "✅ Python version OK: $PYTHON_VERSION"

# Crear entorno virtual
echo "🐍 Configurando entorno virtual..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "✅ Entorno virtual creado"
else
    echo "✅ Entorno virtual ya existe"
fi

# Activar entorno virtual
echo "🔧 Activando entorno virtual..."
source venv/bin/activate

# Actualizar pip
echo "📦 Actualizando pip..."
pip install --upgrade pip

# Instalar dependencias
echo "📚 Instalando dependencias..."
pip install -r requirements.txt

# Configurar variables de entorno
echo "⚙️  Configurando variables de entorno..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "✅ Archivo .env creado desde .env.example"
    echo ""
    echo "🔑 IMPORTANTE: Edita el archivo .env con tu token de GitLab:"
    echo "   GITLAB_PERSONAL_ACCESS_TOKEN=tu_token_aqui"
    echo ""
else
    echo "✅ Archivo .env ya existe"
fi

# Verificar instalación
echo "🧪 Verificando instalación..."
if python -c "import fastmcp, gitlab, pydantic; print('✅ Dependencias OK')" 2>/dev/null; then
    echo "✅ Todas las dependencias instaladas correctamente"
else
    echo "❌ Error en dependencias. Revisa la instalación."
    exit 1
fi

# Test básico de configuración
echo "🔍 Probando configuración básica..."
if [ -f ".env" ]; then
    # Verificar que el archivo .env tiene el token configurado
    if grep -q "GITLAB_PERSONAL_ACCESS_TOKEN=your_gitlab_token_here" .env; then
        echo "⚠️  Configura tu token GitLab en .env antes de usar el servidor"
    else
        echo "✅ Token GitLab configurado en .env"
    fi
fi

echo ""
echo "🎉 ¡Instalación completada!"
echo ""
echo "📋 Próximos pasos:"
echo "1. Edita .env con tu token GitLab:"
echo "   nano .env"
echo ""
echo "2. Activa el entorno virtual:"
echo "   source venv/bin/activate"
echo ""
echo "3. Ejecuta el servidor:"
echo "   python main.py"
echo ""
echo "4. O ejecuta tests:"
echo "   pytest tests/"
echo ""
echo "📚 Documentación completa en README.md"
