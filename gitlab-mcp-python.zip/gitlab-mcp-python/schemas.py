"""
Esquemas Pydantic para validación de datos del GitLab MCP Server
"""
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from enum import Enum

# Esquemas base
class ProjectSchema(BaseModel):
    """Esquema base para operaciones de proyecto"""
    project_id: str = Field(..., description="Project ID or URL-encoded path")

class PaginationSchema(BaseModel):
    """Esquema para paginación"""
    page: Optional[int] = Field(1, ge=1, description="Page number")
    per_page: Optional[int] = Field(20, ge=1, le=100, description="Items per page")

# Enums para estados
class IssueState(str, Enum):
    OPENED = "opened"
    CLOSED = "closed" 
    ALL = "all"

class MergeRequestState(str, Enum):
    OPENED = "opened"
    CLOSED = "closed"
    LOCKED = "locked"
    MERGED = "merged"
    ALL = "all"

class PipelineStatus(str, Enum):
    CREATED = "created"
    WAITING_FOR_RESOURCE = "waiting_for_resource"
    PREPARING = "preparing"
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELED = "canceled"
    SKIPPED = "skipped"
    MANUAL = "manual"
    SCHEDULED = "scheduled"

# Esquemas de búsqueda
class SearchRepositoriesSchema(PaginationSchema):
    """Esquema para búsqueda de repositorios"""
    search: str = Field(..., description="Search query")
    owned: Optional[bool] = Field(None, description="Filter for owned projects")
    membership: Optional[bool] = Field(None, description="Filter for member projects")
    visibility: Optional[str] = Field(None, description="public, internal, private")

# Esquemas de archivos
class FileContentSchema(ProjectSchema):
    """Esquema para obtener contenido de archivos"""
    file_path: str = Field(..., description="Path to the file")
    ref: Optional[str] = Field(None, description="Branch/tag/commit reference")

class CreateOrUpdateFileSchema(ProjectSchema):
    """Esquema para crear o actualizar archivos"""
    file_path: str = Field(..., description="Path to create/update the file")
    content: str = Field(..., description="File content")
    commit_message: str = Field(..., description="Commit message")
    branch: str = Field(..., description="Branch name")
    previous_path: Optional[str] = Field(None, description="Previous path for renames")
    last_commit_id: Optional[str] = Field(None, description="Last commit ID")

# Esquemas de issues
class CreateIssueSchema(ProjectSchema):
    """Esquema para crear issues"""
    title: str = Field(..., description="Issue title")
    description: Optional[str] = Field(None, description="Issue description")
    assignee_ids: Optional[List[int]] = Field(None, description="Assignee user IDs")
    labels: Optional[List[str]] = Field(None, description="Label names")
    milestone_id: Optional[int] = Field(None, description="Milestone ID")
    issue_type: Optional[str] = Field("issue", description="issue, incident, test_case, task")

class ListIssuesSchema(ProjectSchema, PaginationSchema):
    """Esquema para listar issues"""
    state: Optional[IssueState] = Field(IssueState.OPENED, description="Issue state")
    labels: Optional[List[str]] = Field(None, description="Filter by labels")
    assignee_id: Optional[int] = Field(None, description="Filter by assignee")
    author_id: Optional[int] = Field(None, description="Filter by author")
    search: Optional[str] = Field(None, description="Search term")
    created_after: Optional[str] = Field(None, description="Created after date")
    created_before: Optional[str] = Field(None, description="Created before date")

class UpdateIssueSchema(ProjectSchema):
    """Esquema para actualizar issues"""
    issue_iid: int = Field(..., description="Issue IID")
    title: Optional[str] = Field(None, description="New title")
    description: Optional[str] = Field(None, description="New description")
    assignee_ids: Optional[List[int]] = Field(None, description="New assignees")
    labels: Optional[List[str]] = Field(None, description="New labels")
    state_event: Optional[str] = Field(None, description="close or reopen")

# Esquemas de merge requests
class CreateMergeRequestSchema(ProjectSchema):
    """Esquema para crear merge requests"""
    title: str = Field(..., description="MR title")
    source_branch: str = Field(..., description="Source branch")
    target_branch: str = Field(..., description="Target branch")
    description: Optional[str] = Field(None, description="MR description")
    assignee_ids: Optional[List[int]] = Field(None, description="Assignee IDs")
    reviewer_ids: Optional[List[int]] = Field(None, description="Reviewer IDs")
    labels: Optional[List[str]] = Field(None, description="Labels")
    draft: Optional[bool] = Field(False, description="Create as draft")
    remove_source_branch: Optional[bool] = Field(False, description="Remove source branch")
    squash: Optional[bool] = Field(False, description="Squash commits")

class ListMergeRequestsSchema(ProjectSchema, PaginationSchema):
    """Esquema para listar merge requests"""
    state: Optional[MergeRequestState] = Field(MergeRequestState.OPENED, description="MR state")
    assignee_id: Optional[int] = Field(None, description="Filter by assignee")
    author_id: Optional[int] = Field(None, description="Filter by author")
    reviewer_id: Optional[int] = Field(None, description="Filter by reviewer")
    labels: Optional[List[str]] = Field(None, description="Filter by labels")
    target_branch: Optional[str] = Field(None, description="Filter by target branch")
    source_branch: Optional[str] = Field(None, description="Filter by source branch")

class GetMergeRequestSchema(ProjectSchema):
    """Esquema para obtener merge request"""
    merge_request_iid: Optional[int] = Field(None, description="MR IID")
    source_branch: Optional[str] = Field(None, description="Source branch name")

# Esquemas de branches
class CreateBranchSchema(ProjectSchema):
    """Esquema para crear branches"""
    branch_name: str = Field(..., description="New branch name")
    ref: str = Field(..., description="Source branch or commit")

# Esquemas de commits
class ListCommitsSchema(ProjectSchema, PaginationSchema):
    """Esquema para listar commits"""
    ref_name: Optional[str] = Field(None, description="Branch, tag or commit SHA")
    since: Optional[str] = Field(None, description="ISO 8601 date")
    until: Optional[str] = Field(None, description="ISO 8601 date")
    path: Optional[str] = Field(None, description="File path filter")
    author: Optional[str] = Field(None, description="Author filter")
    with_stats: Optional[bool] = Field(False, description="Include commit stats")

# Esquemas de pipelines
class ListPipelinesSchema(ProjectSchema, PaginationSchema):
    """Esquema para listar pipelines"""
    status: Optional[PipelineStatus] = Field(None, description="Pipeline status")
    ref: Optional[str] = Field(None, description="Branch or tag")
    sha: Optional[str] = Field(None, description="Commit SHA")
    username: Optional[str] = Field(None, description="Triggered by user")

class CreatePipelineSchema(ProjectSchema):
    """Esquema para crear pipeline"""
    ref: str = Field(..., description="Branch or tag name")
    variables: Optional[List[Dict[str, str]]] = Field(None, description="Pipeline variables")

# Esquemas de repositorio
class GetRepositoryTreeSchema(ProjectSchema):
    """Esquema para obtener árbol de repositorio"""
    path: Optional[str] = Field(None, description="Path within repository")
    ref: Optional[str] = Field(None, description="Branch, tag or commit")
    recursive: Optional[bool] = Field(False, description="Recursive tree")

# Esquemas de milestones
class CreateMilestoneSchema(ProjectSchema):
    """Esquema para crear milestone"""
    title: str = Field(..., description="Milestone title")
    description: Optional[str] = Field(None, description="Milestone description")
    due_date: Optional[str] = Field(None, description="Due date (YYYY-MM-DD)")
    start_date: Optional[str] = Field(None, description="Start date (YYYY-MM-DD)")

class ListMilestonesSchema(ProjectSchema, PaginationSchema):
    """Esquema para listar milestones"""
    state: Optional[str] = Field(None, description="active or closed")
    search: Optional[str] = Field(None, description="Search term")

# Esquemas de wiki
class CreateWikiPageSchema(ProjectSchema):
    """Esquema para crear página wiki"""
    title: str = Field(..., description="Wiki page title")
    content: str = Field(..., description="Wiki page content")
    format: Optional[str] = Field("markdown", description="Content format")

class UpdateWikiPageSchema(ProjectSchema):
    """Esquema para actualizar página wiki"""
    slug: str = Field(..., description="Wiki page slug")
    title: Optional[str] = Field(None, description="New title")
    content: Optional[str] = Field(None, description="New content")
    format: Optional[str] = Field(None, description="Content format")

# Esquemas de respuesta
class GitLabErrorResponse(BaseModel):
    """Esquema para errores de GitLab"""
    success: bool = False
    error: str
    error_code: Optional[str] = None

class GitLabSuccessResponse(BaseModel):
    """Esquema para respuestas exitosas"""
    success: bool = True
    data: Dict[str, Any]
    message: Optional[str] = None
