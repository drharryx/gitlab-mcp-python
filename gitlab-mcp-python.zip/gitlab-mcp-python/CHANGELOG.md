# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2025-08-28

### Added
- ✅ Migración completa del proyecto [gitlab-mcp](https://github.com/zereight/gitlab-mcp) de TypeScript a Python
- 🚀 Implementación con FastMCP para servidor MCP simplificado
- 🔧 30+ herramientas GitLab organizadas por categorías:
  - **Repositorios**: search_repositories, get_project, get_file_contents, create_or_update_file, get_repository_tree, create_branch, list_commits
  - **Issues**: create_issue, list_issues, get_issue, update_issue, delete_issue
  - **Merge Requests**: create_merge_request, list_merge_requests, get_merge_request, update_merge_request, merge_merge_request
  - **Utilidades**: server_info, test_connection
- 🔒 Sistema de autenticación flexible con tokens GitLab
- 📊 Configuración granular con variables de entorno
- 🛡️ Modo solo lectura para operaciones seguras
- 📝 Sistema de logging detallado
- 🧪 Suite de tests básicos con pytest
- 📚 Documentación completa con ejemplos
- 🔄 GitHub Actions para CI/CD

### Technical Details
- **Framework**: FastMCP (Python MCP SDK)
- **Cliente GitLab**: python-gitlab (cliente oficial)
- **Validación**: Pydantic para esquemas de datos
- **Configuración**: Pydantic Settings para variables de entorno
- **Testing**: pytest con mocks para GitLab API
- **Estructura**: Arquitectura modular por categorías de herramientas

### Migration Notes
- ✅ Compatibilidad completa con servidor TypeScript original
- 🔄 API idéntica para todas las herramientas implementadas
- 📈 Mejor performance con python-gitlab optimizado
- 🐛 Mejor debugging con logging estructurado
- 🛡️ Validación mejorada con Pydantic

### Requirements
- Python 3.9+
- GitLab Personal Access Token
- Permisos de API en instancia GitLab

### Breaking Changes
- Ninguno - compatibilidad completa mantenida

## [Unreleased]

### Planned Features
- [ ] Herramientas de pipelines (CI/CD)
- [ ] Gestión de milestones
- [ ] Funcionalidades de Wiki GitLab
- [ ] Soporte para comentarios y discusiones
- [ ] Gestión de etiquetas y usuarios
- [ ] Transporte HTTP/SSE además de STDIO
- [ ] Cache de respuestas GitLab
- [ ] Rate limiting inteligente
- [ ] Webhooks GitLab
- [ ] Métricas y monitoreo

### Known Issues
- Herramientas de pipelines requieren configuración USE_PIPELINE=true
- Algunas funcionalidades avanzadas del proyecto original pendientes
- Transporte HTTP aún no implementado (solo STDIO)

---

Para más detalles sobre cambios específicos, ver el [commit history](../../commits/main).
