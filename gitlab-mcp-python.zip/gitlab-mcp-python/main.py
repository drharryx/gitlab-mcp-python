#!/usr/bin/env python3
"""
GitLab MCP Python Server
Implementación en Python del servidor GitLab MCP
"""
import asyncio
import logging
import sys
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Importar FastMCP
try:
    from fastmcp import FastMCP
except ImportError:
    logger.error("FastMCP no está instalado. Ejecuta: pip install fastmcp")
    sys.exit(1)

# Importar nuestros módulos
try:
    from config import config
    from gitlab_client import gitlab_client
    from tools import (
        register_repository_tools,
        register_issues_tools,
        register_merge_requests_tools
    )
except ImportError as e:
    logger.error(f"Error importando módulos: {e}")
    logger.error("Asegúrate de que todos los archivos estén en el directorio correcto")
    sys.exit(1)

# Crear instancia del servidor MCP
app = FastMCP(
    name="gitlab-mcp-python",
    description="GitLab MCP Server implementado en Python con FastMCP"
)

def register_all_tools():
    """Registra todas las herramientas disponibles"""
    logger.info("Registrando herramientas del servidor GitLab MCP...")

    try:
        # Registrar herramientas básicas de repositorio
        logger.info("Registrando herramientas de repositorio...")
        register_repository_tools(app, gitlab_client, config)

        # Registrar herramientas de issues
        logger.info("Registrando herramientas de issues...")
        register_issues_tools(app, gitlab_client, config)

        # Registrar herramientas de merge requests
        logger.info("Registrando herramientas de merge requests...")
        register_merge_requests_tools(app, gitlab_client, config)

        logger.info("Todas las herramientas registradas exitosamente")

    except Exception as e:
        logger.error(f"Error registrando herramientas: {e}")
        raise

@app.tool()
def server_info() -> dict:
    """Información del servidor GitLab MCP Python"""
    return {
        "success": True,
        "server": {
            "name": "gitlab-mcp-python",
            "version": "1.0.0",
            "description": "GitLab MCP Server implementado en Python",
            "framework": "FastMCP",
            "gitlab_api_url": config.api_url,
            "read_only_mode": config.read_only_mode,
            "features": {
                "gitlab_wiki": config.use_gitlab_wiki,
                "milestones": config.use_milestone,
                "pipelines": config.use_pipeline
            },
            "project_config": {
                "default_project_id": config.project_id,
                "allowed_projects": config.get_allowed_project_ids(),
                "has_restrictions": bool(config.get_allowed_project_ids())
            }
        }
    }

@app.tool() 
def test_connection() -> dict:
    """Probar conexión con GitLab API"""
    try:
        user = gitlab_client.current_user
        return {
            "success": True,
            "connection": "OK",
            "user": {
                "id": user.id,
                "username": user.username,
                "name": user.name,
                "email": getattr(user, 'email', 'N/A')
            },
            "api_url": config.api_url
        }
    except Exception as e:
        logger.error(f"Error testing connection: {e}")
        return {
            "success": False,
            "connection": "FAILED", 
            "error": str(e)
        }

def main():
    """Función principal del servidor"""
    try:
        logger.info("Iniciando GitLab MCP Python Server...")
        logger.info(f"GitLab API URL: {config.api_url}")
        logger.info(f"Read-only mode: {config.read_only_mode}")
        logger.info(f"Wiki enabled: {config.use_gitlab_wiki}")
        logger.info(f"Milestones enabled: {config.use_milestone}")
        logger.info(f"Pipelines enabled: {config.use_pipeline}")

        if config.project_id:
            logger.info(f"Default project: {config.project_id}")

        if config.get_allowed_project_ids():
            logger.info(f"Allowed projects: {config.get_allowed_project_ids()}")

        # Probar conexión con GitLab
        logger.info("Probando conexión con GitLab...")
        test_result = test_connection()
        if not test_result["success"]:
            logger.error(f"Fallo de conexión con GitLab: {test_result['error']}")
            sys.exit(1)

        logger.info(f"Conectado como: {test_result['user']['username']} ({test_result['user']['name']})")

        # Registrar herramientas
        register_all_tools()

        logger.info("Servidor GitLab MCP Python iniciado exitosamente")
        logger.info("Ejecutando con transporte STDIO...")

        # Ejecutar servidor con transporte STDIO
        app.run(transport="stdio")

    except KeyboardInterrupt:
        logger.info("Servidor interrumpido por el usuario")
    except Exception as e:
        logger.error(f"Error crítico: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
