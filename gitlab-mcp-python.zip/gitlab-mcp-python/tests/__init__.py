# Tests for GitLab MCP Python Server
