"""
Tests básicos para GitLab MCP Python Server
"""
import pytest
import os
from unittest.mock import Mock, patch

def test_config_loading():
    """Test carga de configuración"""
    from config import GitLabConfig

    # Test con variables por defecto
    config = GitLabConfig(
        personal_access_token="test_token",
        api_url="https://gitlab.example.com/api/v4"
    )

    assert config.personal_access_token == "test_token"
    assert config.api_url == "https://gitlab.example.com/api/v4"
    assert config.read_only_mode == False
    assert config.use_gitlab_wiki == False

def test_project_id_restrictions():
    """Test restricciones de project_id"""
    from config import GitLabConfig

    config = GitLabConfig(
        personal_access_token="test_token",
        allowed_project_ids="123,456,789"
    )

    allowed_ids = config.get_allowed_project_ids()
    assert "123" in allowed_ids
    assert "456" in allowed_ids
    assert "789" in allowed_ids

    assert config.is_project_allowed("123") == True
    assert config.is_project_allowed("999") == False

@patch('gitlab.Gitlab')
def test_gitlab_client_init(mock_gitlab):
    """Test inicialización del cliente GitLab"""
    # Mock del cliente GitLab
    mock_gl = Mock()
    mock_user = Mock()
    mock_user.username = "testuser"
    mock_gl.user = mock_user
    mock_gitlab.return_value = mock_gl

    from gitlab_client import GitLabClient

    # Simular inicialización exitosa
    with patch.dict(os.environ, {
        'GITLAB_PERSONAL_ACCESS_TOKEN': 'test_token',
        'GITLAB_API_URL': 'https://gitlab.com/api/v4'
    }):
        client = GitLabClient()
        assert client.current_user.username == "testuser"

def test_server_info_tool():
    """Test herramienta server_info"""
    from main import server_info

    result = server_info()

    assert result["success"] == True
    assert "server" in result
    assert result["server"]["name"] == "gitlab-mcp-python"
    assert "version" in result["server"]

@pytest.mark.asyncio 
async def test_search_repositories_schema():
    """Test esquema de búsqueda de repositorios"""
    from schemas import SearchRepositoriesSchema

    # Test datos válidos
    valid_data = {
        "search": "test project",
        "page": 1,
        "per_page": 20
    }

    schema = SearchRepositoriesSchema(**valid_data)
    assert schema.search == "test project"
    assert schema.page == 1
    assert schema.per_page == 20

def test_create_issue_schema():
    """Test esquema de creación de issues"""
    from schemas import CreateIssueSchema

    valid_data = {
        "project_id": "123",
        "title": "Test Issue",
        "description": "Test description",
        "labels": ["bug", "urgent"]
    }

    schema = CreateIssueSchema(**valid_data)
    assert schema.project_id == "123"
    assert schema.title == "Test Issue"
    assert schema.labels == ["bug", "urgent"]

if __name__ == "__main__":
    pytest.main([__file__])
