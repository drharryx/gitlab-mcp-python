"""
Cliente GitLab wrapper para el servidor MCP Python
"""
import gitlab
import logging
from typing import Optional, Dict, Any, List, Union
from config import config
from gitlab.exceptions import GitlabError, GitlabAuthenticationError

# Configurar logging
logger = logging.getLogger(__name__)

class GitLabClient:
    """Wrapper del cliente GitLab con funcionalidades específicas para MCP"""

    def __init__(self):
        """Inicializar cliente GitLab"""
        try:
            self.gl = gitlab.Gitlab(
                url=config.api_url,
                private_token=config.personal_access_token,
                timeout=30
            )
            # Verificar autenticación
            self.gl.auth()
            self.current_user = self.gl.user
            logger.info(f"GitLab client initialized for user: {self.current_user.username}")
        except GitlabAuthenticationError as e:
            logger.error(f"GitLab authentication failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Failed to initialize GitLab client: {e}")
            raise

    def get_effective_project_id(self, project_id: Optional[str] = None) -> str:
        """Obtiene el ID efectivo del proyecto a usar"""
        # Prioridad: project_id parameter > config.project_id > error
        if project_id:
            if config.is_project_allowed(project_id):
                return project_id
            else:
                raise ValueError(f"Project {project_id} is not in allowed projects list")

        if config.project_id:
            return config.project_id

        raise ValueError("No project ID specified and no default project configured")

    def get_project(self, project_id: Optional[str] = None):
        """Obtiene un proyecto por ID"""
        effective_id = self.get_effective_project_id(project_id)
        try:
            return self.gl.projects.get(effective_id)
        except GitlabError as e:
            logger.error(f"Failed to get project {effective_id}: {e}")
            raise

    def search_projects(self, search: str, **kwargs) -> List:
        """Busca proyectos"""
        try:
            return self.gl.projects.list(search=search, all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to search projects: {e}")
            raise

    def list_projects(self, **kwargs) -> List:
        """Lista proyectos accesibles"""
        try:
            return self.gl.projects.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list projects: {e}")
            raise

    # Métodos para issues
    def create_issue(self, project_id: str, issue_data: Dict[str, Any]):
        """Crea una nueva issue"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot create issues")

        project = self.get_project(project_id)
        try:
            return project.issues.create(issue_data)
        except GitlabError as e:
            logger.error(f"Failed to create issue: {e}")
            raise

    def list_issues(self, project_id: str, **kwargs) -> List:
        """Lista issues de un proyecto"""
        project = self.get_project(project_id)
        try:
            return project.issues.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list issues: {e}")
            raise

    def get_issue(self, project_id: str, issue_iid: int):
        """Obtiene una issue específica"""
        project = self.get_project(project_id)
        try:
            return project.issues.get(issue_iid)
        except GitlabError as e:
            logger.error(f"Failed to get issue {issue_iid}: {e}")
            raise

    def update_issue(self, project_id: str, issue_iid: int, update_data: Dict[str, Any]):
        """Actualiza una issue"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot update issues")

        issue = self.get_issue(project_id, issue_iid)
        try:
            for key, value in update_data.items():
                setattr(issue, key, value)
            issue.save()
            return issue
        except GitlabError as e:
            logger.error(f"Failed to update issue {issue_iid}: {e}")
            raise

    # Métodos para merge requests
    def create_merge_request(self, project_id: str, mr_data: Dict[str, Any]):
        """Crea un nuevo merge request"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot create merge requests")

        project = self.get_project(project_id)
        try:
            return project.mergerequests.create(mr_data)
        except GitlabError as e:
            logger.error(f"Failed to create merge request: {e}")
            raise

    def list_merge_requests(self, project_id: str, **kwargs) -> List:
        """Lista merge requests de un proyecto"""
        project = self.get_project(project_id)
        try:
            return project.mergerequests.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list merge requests: {e}")
            raise

    def get_merge_request(self, project_id: str, mr_iid: int):
        """Obtiene un merge request específico"""
        project = self.get_project(project_id)
        try:
            return project.mergerequests.get(mr_iid)
        except GitlabError as e:
            logger.error(f"Failed to get merge request {mr_iid}: {e}")
            raise

    # Métodos para archivos
    def get_file(self, project_id: str, file_path: str, ref: str = "main"):
        """Obtiene un archivo del repositorio"""
        project = self.get_project(project_id)
        try:
            return project.files.get(file_path=file_path, ref=ref)
        except GitlabError as e:
            logger.error(f"Failed to get file {file_path}: {e}")
            raise

    def create_file(self, project_id: str, file_data: Dict[str, Any]):
        """Crea un nuevo archivo"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot create files")

        project = self.get_project(project_id)
        try:
            return project.files.create(file_data)
        except GitlabError as e:
            logger.error(f"Failed to create file: {e}")
            raise

    def update_file(self, project_id: str, file_path: str, file_data: Dict[str, Any]):
        """Actualiza un archivo existente"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot update files")

        project = self.get_project(project_id)
        try:
            file_obj = project.files.get(file_path=file_path, ref=file_data.get('branch', 'main'))
            for key, value in file_data.items():
                if hasattr(file_obj, key):
                    setattr(file_obj, key, value)
            file_obj.save()
            return file_obj
        except GitlabError as e:
            logger.error(f"Failed to update file {file_path}: {e}")
            raise

    # Métodos para branches
    def create_branch(self, project_id: str, branch_name: str, ref: str):
        """Crea una nueva rama"""
        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot create branches")

        project = self.get_project(project_id)
        try:
            return project.branches.create({'branch': branch_name, 'ref': ref})
        except GitlabError as e:
            logger.error(f"Failed to create branch {branch_name}: {e}")
            raise

    def list_branches(self, project_id: str, **kwargs) -> List:
        """Lista ramas del proyecto"""
        project = self.get_project(project_id)
        try:
            return project.branches.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list branches: {e}")
            raise

    # Métodos para commits
    def list_commits(self, project_id: str, **kwargs) -> List:
        """Lista commits del proyecto"""
        project = self.get_project(project_id)
        try:
            return project.commits.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list commits: {e}")
            raise

    def get_commit(self, project_id: str, commit_sha: str):
        """Obtiene un commit específico"""
        project = self.get_project(project_id)
        try:
            return project.commits.get(commit_sha)
        except GitlabError as e:
            logger.error(f"Failed to get commit {commit_sha}: {e}")
            raise

    # Métodos para pipelines (si está habilitado)
    def list_pipelines(self, project_id: str, **kwargs) -> List:
        """Lista pipelines del proyecto"""
        if not config.use_pipeline:
            raise ValueError("Pipeline functionality is disabled")

        project = self.get_project(project_id)
        try:
            return project.pipelines.list(all=True, **kwargs)
        except GitlabError as e:
            logger.error(f"Failed to list pipelines: {e}")
            raise

    def create_pipeline(self, project_id: str, ref: str, variables: Optional[List[Dict]] = None):
        """Crea un nuevo pipeline"""
        if not config.use_pipeline:
            raise ValueError("Pipeline functionality is disabled")

        if config.read_only_mode:
            raise ValueError("Read-only mode enabled - cannot create pipelines")

        project = self.get_project(project_id)
        try:
            pipeline_data = {'ref': ref}
            if variables:
                pipeline_data['variables'] = variables
            return project.pipelines.create(pipeline_data)
        except GitlabError as e:
            logger.error(f"Failed to create pipeline: {e}")
            raise

# Instancia global del cliente
gitlab_client = GitLabClient()
