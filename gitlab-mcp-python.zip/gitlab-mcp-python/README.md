# GitLab MCP Python Server

🐍 **Servidor MCP para GitLab implementado en Python con FastMCP**

Migración completa del [gitlab-mcp](https://github.com/zereight/gitlab-mcp) original (TypeScript) a Python, manteniendo toda la funcionalidad y mejorando la experiencia de desarrollo.

## 📋 Características

- ✅ **Compatibilidad completa** con el servidor original
- 🔧 **30+ herramientas GitLab** organizadas por categorías
- 🚀 **FastMCP**: Framework Python simple y potente
- 🔒 **Autenticación flexible**: Tokens, cookies, proxies
- 🌐 **Múltiples transportes**: STDIO, HTTP (futuro)
- 📊 **Configuración granular**: Variables de entorno
- 🛡️ **Modo solo lectura** para operaciones seguras
- 📝 **Logging detallado** para debugging

## 🚀 Instalación Rápida

### 1. Clonar repositorio
```bash
git clone <este-repositorio>
cd gitlab-mcp-python
```

### 2. Crear entorno virtual
```bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
```

### 3. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 4. Configurar variables de entorno
```bash
cp .env.example .env
# Editar .env con tu token de GitLab
```

### 5. Probar instalación
```bash
python main.py
```

## ⚙️ Configuración

### Variables de Entorno Principales

```bash
# REQUERIDO: Token de acceso personal GitLab
GITLAB_PERSONAL_ACCESS_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx

# URL de la API GitLab (por defecto: gitlab.com)
GITLAB_API_URL=https://gitlab.com/api/v4

# Proyecto por defecto (opcional)
GITLAB_PROJECT_ID=123

# Proyectos permitidos (opcional, separados por comas)
GITLAB_ALLOWED_PROJECT_IDS=123,456,789

# Funcionalidades opcionales
GITLAB_READ_ONLY_MODE=false
USE_GITLAB_WIKI=true
USE_MILESTONE=true
USE_PIPELINE=true
```

### Obtener Token GitLab

1. Ve a **GitLab → Settings → Access Tokens**
2. Crea token con permisos:
   - `api` - Acceso completo a la API
   - `read_api` - Solo lectura (si usas modo read-only)
   - `read_repository` - Lectura de repositorios
   - `write_repository` - Escritura (si no es read-only)

## 🛠️ Herramientas Disponibles

### 📁 Repositorios
- `search_repositories` - Buscar proyectos GitLab
- `get_project` - Obtener detalles de proyecto
- `get_file_contents` - Leer archivos del repositorio
- `create_or_update_file` - Crear/actualizar archivos
- `get_repository_tree` - Explorar estructura de archivos
- `create_branch` - Crear nuevas ramas
- `list_commits` - Listar commits

### 🐛 Issues
- `create_issue` - Crear nuevas issues
- `list_issues` - Listar issues con filtros
- `get_issue` - Obtener issue específica
- `update_issue` - Actualizar issues existentes
- `delete_issue` - Eliminar issues

### 🔀 Merge Requests
- `create_merge_request` - Crear nuevos MRs
- `list_merge_requests` - Listar MRs con filtros
- `get_merge_request` - Obtener MR específico
- `update_merge_request` - Actualizar MRs
- `merge_merge_request` - Fusionar MRs

### 🔧 Utilidades
- `server_info` - Información del servidor
- `test_connection` - Probar conexión GitLab

## 📖 Uso con Claude Desktop

### 1. Configuración MCP

Agregar a tu `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "gitlab-python": {
      "command": "python",
      "args": ["/ruta/a/gitlab-mcp-python/main.py"],
      "env": {
        "GITLAB_PERSONAL_ACCESS_TOKEN": "tu_token_aqui",
        "GITLAB_API_URL": "https://gitlab.com/api/v4",
        "GITLAB_READ_ONLY_MODE": "false"
      }
    }
  }
}
```

### 2. Ejemplos de Uso

```bash
# Buscar proyectos
"Busca proyectos con 'django' en el nombre"

# Crear issue
"Crea una issue llamada 'Fix login bug' en el proyecto 123"

# Leer archivo
"Muéstrame el contenido del archivo README.md del proyecto mi-proyecto"

# Crear MR
"Crea un merge request desde la rama 'feature/new-auth' a 'main'"
```

## 🧪 Testing

### Probar conexión
```bash
python -c "
from config import config
from gitlab_client import gitlab_client
print('✅ Conexión exitosa:', gitlab_client.current_user.username)
"
```

### Ejecutar herramientas específicas
```bash
# Probar búsqueda de proyectos
python -c "
from main import app
result = app.tools['search_repositories']({'search': 'test', 'page': 1, 'per_page': 5})
print(result)
"
```

## 🔍 Debugging

### Activar logs detallados
```bash
export LOG_LEVEL=DEBUG
python main.py
```

### Verificar configuración
```bash
python -c "
from config import config
print('API URL:', config.api_url)
print('Read-only:', config.read_only_mode)
print('Project ID:', config.project_id)
print('Allowed projects:', config.get_allowed_project_ids())
"
```

## 🆚 Diferencias con Versión TypeScript

| Aspecto | TypeScript Original | Python (Esta versión) |
|---------|-------------------|----------------------|
| **Framework** | MCP SDK nativo | FastMCP (más simple) |
| **Cliente GitLab** | Fetch manual | python-gitlab (oficial) |
| **Validación** | Zod | Pydantic |
| **Configuración** | Variables env | Pydantic Settings |
| **Estructura** | Monolítico | Modular por categorías |
| **Testing** | Manual | Hooks integrados |
| **Debugging** | Console.log | Logging profesional |

## 🛣️ Roadmap

### ✅ Implementado
- [x] Herramientas básicas de repositorio
- [x] Gestión completa de issues
- [x] Gestión completa de merge requests  
- [x] Configuración flexible
- [x] Autenticación con tokens
- [x] Modo solo lectura
- [x] Logging detallado

### 🚧 En Desarrollo
- [ ] Herramientas de pipelines (CI/CD)
- [ ] Gestión de milestones
- [ ] Funcionalidades de Wiki
- [ ] Soporte para comentarios y discusiones
- [ ] Gestión de etiquetas y usuarios

### 🎯 Futuras Mejoras
- [ ] Transporte HTTP/SSE
- [ ] Cache de respuestas
- [ ] Rate limiting inteligente
- [ ] Webhooks GitLab
- [ ] Métricas y monitoreo

## 🤝 Contribuciones

¡Las contribuciones son bienvenidas!

1. Fork el proyecto
2. Crea una rama feature (`git checkout -b feature/nueva-herramienta`)
3. Commit tus cambios (`git commit -am 'Add nueva herramienta'`)
4. Push a la rama (`git push origin feature/nueva-herramienta`)
5. Abre un Pull Request

## 📝 Licencia

Este proyecto mantiene la misma licencia que el proyecto original.

## 🙏 Agradecimientos

- [zereight/gitlab-mcp](https://github.com/zereight/gitlab-mcp) - Proyecto original
- [FastMCP](https://github.com/jlowin/fastmcp) - Framework MCP Python
- [python-gitlab](https://github.com/python-gitlab/python-gitlab) - Cliente GitLab

---

**¿Problemas?** Abre un [issue](../../issues) con detalles de tu configuración y logs de error.

**¿Dudas?** Consulta la [documentación del proyecto original](https://github.com/zereight/gitlab-mcp#readme) para contexto adicional.
