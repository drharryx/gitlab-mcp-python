"""
Herramientas GitLab MCP organizadas por categorías
"""
from .repository import register_repository_tools
from .issues import register_issues_tools  
from .merge_requests import register_merge_requests_tools

__all__ = [
    'register_repository_tools',
    'register_issues_tools', 
    'register_merge_requests_tools'
]
