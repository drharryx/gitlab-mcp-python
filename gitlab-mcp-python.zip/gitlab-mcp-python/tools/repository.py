"""
Herramientas para gestión de repositorios GitLab
"""
import logging
from typing import Dict, Any, List
from fastmcp import FastMCP
from schemas import *
from gitlab_client import GitLabClient
from config import GitLabConfig

logger = logging.getLogger(__name__)

def register_repository_tools(app: FastMCP, gitlab_client: GitLabClient, config: GitLabConfig):
    """Registra herramientas de gestión de repositorios"""

    @app.tool()
    def search_repositories(params: SearchRepositoriesSchema) -> Dict[str, Any]:
        """Buscar repositorios GitLab"""
        try:
            projects = gitlab_client.search_projects(
                search=params.search,
                owned=params.owned,
                membership=params.membership,
                visibility=params.visibility,
                page=params.page,
                per_page=params.per_page
            )

            project_list = []
            for project in projects:
                project_data = {
                    "id": project.id,
                    "name": project.name,
                    "path_with_namespace": project.path_with_namespace,
                    "description": getattr(project, 'description', None),
                    "web_url": project.web_url,
                    "visibility": getattr(project, 'visibility', None),
                    "default_branch": getattr(project, 'default_branch', None),
                    "created_at": getattr(project, 'created_at', None),
                    "last_activity_at": getattr(project, 'last_activity_at', None),
                    "star_count": getattr(project, 'star_count', 0),
                    "forks_count": getattr(project, 'forks_count', 0)
                }
                project_list.append(project_data)

            return {
                "success": True,
                "projects": project_list,
                "count": len(project_list),
                "page": params.page,
                "per_page": params.per_page
            }

        except Exception as e:
            logger.error(f"Error searching repositories: {e}")
            return {
                "success": False,
                "error": str(e),
                "projects": [],
                "count": 0
            }

    @app.tool()
    def get_project(params: ProjectSchema) -> Dict[str, Any]:
        """Obtener detalles de un proyecto específico"""
        try:
            project = gitlab_client.get_project(params.project_id)

            project_data = {
                "id": project.id,
                "name": project.name,
                "path": project.path,
                "path_with_namespace": project.path_with_namespace,
                "description": getattr(project, 'description', None),
                "web_url": project.web_url,
                "visibility": getattr(project, 'visibility', None),
                "default_branch": getattr(project, 'default_branch', 'main'),
                "created_at": getattr(project, 'created_at', None),
                "last_activity_at": getattr(project, 'last_activity_at', None),
                "star_count": getattr(project, 'star_count', 0),
                "forks_count": getattr(project, 'forks_count', 0),
                "open_issues_count": getattr(project, 'open_issues_count', 0),
                "topics": getattr(project, 'topics', []),
                "archived": getattr(project, 'archived', False),
                "issues_enabled": getattr(project, 'issues_enabled', True),
                "merge_requests_enabled": getattr(project, 'merge_requests_enabled', True),
                "wiki_enabled": getattr(project, 'wiki_enabled', True),
                "namespace": {
                    "id": project.namespace.get('id') if hasattr(project, 'namespace') else None,
                    "name": project.namespace.get('name') if hasattr(project, 'namespace') else None,
                    "path": project.namespace.get('path') if hasattr(project, 'namespace') else None,
                    "kind": project.namespace.get('kind') if hasattr(project, 'namespace') else None
                }
            }

            return {
                "success": True,
                "project": project_data
            }

        except Exception as e:
            logger.error(f"Error getting project: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def get_file_contents(params: FileContentSchema) -> Dict[str, Any]:
        """Obtener contenido de un archivo del repositorio"""
        try:
            # Si no se especifica ref, usar el branch por defecto
            if not params.ref:
                project = gitlab_client.get_project(params.project_id)
                params.ref = getattr(project, 'default_branch', 'main')

            file_obj = gitlab_client.get_file(params.project_id, params.file_path, params.ref)

            # Decodificar contenido
            content = file_obj.decode().decode('utf-8') if hasattr(file_obj, 'decode') else str(file_obj.content)

            file_data = {
                "file_name": getattr(file_obj, 'file_name', params.file_path.split('/')[-1]),
                "file_path": file_obj.file_path if hasattr(file_obj, 'file_path') else params.file_path,
                "size": getattr(file_obj, 'size', len(content)),
                "encoding": getattr(file_obj, 'encoding', 'utf-8'),
                "content": content,
                "ref": params.ref,
                "commit_id": getattr(file_obj, 'commit_id', None),
                "last_commit_id": getattr(file_obj, 'last_commit_id', None)
            }

            return {
                "success": True,
                "file": file_data
            }

        except Exception as e:
            logger.error(f"Error getting file contents: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def create_or_update_file(params: CreateOrUpdateFileSchema) -> Dict[str, Any]:
        """Crear o actualizar un archivo en el repositorio"""
        try:
            file_data = {
                'file_path': params.file_path,
                'branch': params.branch,
                'content': params.content,
                'commit_message': params.commit_message,
                'encoding': 'text'
            }

            if params.previous_path:
                file_data['previous_path'] = params.previous_path

            if params.last_commit_id:
                file_data['last_commit_id'] = params.last_commit_id

            # Intentar actualizar primero, si no existe crear
            try:
                file_obj = gitlab_client.update_file(params.project_id, params.file_path, file_data)
                action = "updated"
            except Exception:
                # Si falla la actualización, intentar crear
                file_obj = gitlab_client.create_file(params.project_id, file_data)
                action = "created"

            return {
                "success": True,
                "action": action,
                "file_path": params.file_path,
                "branch": params.branch,
                "commit_id": getattr(file_obj, 'commit_id', None)
            }

        except Exception as e:
            logger.error(f"Error creating/updating file: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def get_repository_tree(params: GetRepositoryTreeSchema) -> Dict[str, Any]:
        """Obtener el árbol de archivos del repositorio"""
        try:
            project = gitlab_client.get_project(params.project_id)

            # Parámetros para la consulta
            tree_params = {}
            if params.path:
                tree_params['path'] = params.path
            if params.ref:
                tree_params['ref'] = params.ref
            if params.recursive:
                tree_params['recursive'] = params.recursive

            # Obtener el árbol
            tree_items = project.repository_tree(all=True, **tree_params)

            tree_list = []
            for item in tree_items:
                tree_data = {
                    "id": item.get('id'),
                    "name": item.get('name'),
                    "type": item.get('type'),  # 'tree' o 'blob'
                    "path": item.get('path'),
                    "mode": item.get('mode')
                }
                tree_list.append(tree_data)

            return {
                "success": True,
                "tree": tree_list,
                "count": len(tree_list),
                "path": params.path or "/",
                "ref": params.ref or project.default_branch
            }

        except Exception as e:
            logger.error(f"Error getting repository tree: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def create_branch(params: CreateBranchSchema) -> Dict[str, Any]:
        """Crear una nueva rama"""
        try:
            branch = gitlab_client.create_branch(
                params.project_id,
                params.branch_name,
                params.ref
            )

            branch_data = {
                "name": branch.name,
                "commit": {
                    "id": branch.commit.get('id') if hasattr(branch, 'commit') else None,
                    "message": branch.commit.get('message') if hasattr(branch, 'commit') else None,
                    "author_name": branch.commit.get('author_name') if hasattr(branch, 'commit') else None
                }
            }

            return {
                "success": True,
                "branch": branch_data,
                "message": f"Branch '{params.branch_name}' created successfully"
            }

        except Exception as e:
            logger.error(f"Error creating branch: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def list_commits(params: ListCommitsSchema) -> Dict[str, Any]:
        """Listar commits del repositorio"""
        try:
            commit_params = {
                'page': params.page,
                'per_page': params.per_page
            }

            if params.ref_name:
                commit_params['ref_name'] = params.ref_name
            if params.since:
                commit_params['since'] = params.since
            if params.until:
                commit_params['until'] = params.until
            if params.path:
                commit_params['path'] = params.path
            if params.author:
                commit_params['author'] = params.author
            if params.with_stats:
                commit_params['with_stats'] = params.with_stats

            commits = gitlab_client.list_commits(params.project_id, **commit_params)

            commit_list = []
            for commit in commits:
                commit_data = {
                    "id": commit.id,
                    "short_id": getattr(commit, 'short_id', commit.id[:8]),
                    "title": getattr(commit, 'title', ''),
                    "message": getattr(commit, 'message', ''),
                    "author_name": getattr(commit, 'author_name', ''),
                    "author_email": getattr(commit, 'author_email', ''),
                    "authored_date": getattr(commit, 'authored_date', ''),
                    "committer_name": getattr(commit, 'committer_name', ''),
                    "committer_email": getattr(commit, 'committer_email', ''),
                    "committed_date": getattr(commit, 'committed_date', ''),
                    "created_at": getattr(commit, 'created_at', ''),
                    "web_url": getattr(commit, 'web_url', '')
                }

                if params.with_stats and hasattr(commit, 'stats'):
                    commit_data['stats'] = {
                        'additions': commit.stats.get('additions', 0),
                        'deletions': commit.stats.get('deletions', 0),
                        'total': commit.stats.get('total', 0)
                    }

                commit_list.append(commit_data)

            return {
                "success": True,
                "commits": commit_list,
                "count": len(commit_list),
                "page": params.page,
                "per_page": params.per_page
            }

        except Exception as e:
            logger.error(f"Error listing commits: {e}")
            return {
                "success": False,
                "error": str(e)
            }
