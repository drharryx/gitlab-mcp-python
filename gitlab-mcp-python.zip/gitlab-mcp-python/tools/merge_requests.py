"""
Herramientas para gestión de merge requests GitLab
"""
import logging
from typing import Dict, Any, List
from fastmcp import FastMCP
from schemas import *
from gitlab_client import GitLabClient
from config import GitLabConfig

logger = logging.getLogger(__name__)

def register_merge_requests_tools(app: FastMCP, gitlab_client: GitLabClient, config: GitLabConfig):
    """Registra herramientas de gestión de merge requests"""

    @app.tool()
    def create_merge_request(params: CreateMergeRequestSchema) -> Dict[str, Any]:
        """Crear un nuevo merge request"""
        try:
            mr_data = {
                'title': params.title,
                'source_branch': params.source_branch,
                'target_branch': params.target_branch,
                'description': params.description or ''
            }

            if params.assignee_ids:
                mr_data['assignee_ids'] = params.assignee_ids

            if params.reviewer_ids:
                mr_data['reviewer_ids'] = params.reviewer_ids

            if params.labels:
                mr_data['labels'] = ','.join(params.labels)

            if params.draft:
                mr_data['draft'] = params.draft

            if params.remove_source_branch:
                mr_data['remove_source_branch'] = params.remove_source_branch

            if params.squash:
                mr_data['squash'] = params.squash

            mr = gitlab_client.create_merge_request(params.project_id, mr_data)

            mr_result = {
                "id": mr.id,
                "iid": mr.iid,
                "title": mr.title,
                "description": getattr(mr, 'description', ''),
                "state": mr.state,
                "source_branch": mr.source_branch,
                "target_branch": mr.target_branch,
                "author": {
                    "id": mr.author.get('id') if hasattr(mr, 'author') else None,
                    "name": mr.author.get('name') if hasattr(mr, 'author') else None,
                    "username": mr.author.get('username') if hasattr(mr, 'author') else None
                },
                "assignees": [
                    {
                        "id": assignee.get('id'),
                        "name": assignee.get('name'),
                        "username": assignee.get('username')
                    }
                    for assignee in getattr(mr, 'assignees', [])
                ],
                "reviewers": [
                    {
                        "id": reviewer.get('id'),
                        "name": reviewer.get('name'),
                        "username": reviewer.get('username')
                    }
                    for reviewer in getattr(mr, 'reviewers', [])
                ],
                "labels": getattr(mr, 'labels', []),
                "draft": getattr(mr, 'draft', False),
                "created_at": getattr(mr, 'created_at', ''),
                "updated_at": getattr(mr, 'updated_at', ''),
                "web_url": mr.web_url,
                "merge_status": getattr(mr, 'merge_status', ''),
                "detailed_merge_status": getattr(mr, 'detailed_merge_status', '')
            }

            return {
                "success": True,
                "merge_request": mr_result,
                "message": f"Merge request '!{mr.iid} - {mr.title}' created successfully"
            }

        except Exception as e:
            logger.error(f"Error creating merge request: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def list_merge_requests(params: ListMergeRequestsSchema) -> Dict[str, Any]:
        """Listar merge requests del proyecto"""
        try:
            mr_params = {
                'state': params.state.value if params.state else 'opened',
                'page': params.page,
                'per_page': params.per_page
            }

            if params.assignee_id:
                mr_params['assignee_id'] = params.assignee_id

            if params.author_id:
                mr_params['author_id'] = params.author_id

            if params.reviewer_id:
                mr_params['reviewer_id'] = params.reviewer_id

            if params.labels:
                mr_params['labels'] = ','.join(params.labels)

            if params.target_branch:
                mr_params['target_branch'] = params.target_branch

            if params.source_branch:
                mr_params['source_branch'] = params.source_branch

            merge_requests = gitlab_client.list_merge_requests(params.project_id, **mr_params)

            mr_list = []
            for mr in merge_requests:
                mr_data = {
                    "id": mr.id,
                    "iid": mr.iid,
                    "title": mr.title,
                    "description": getattr(mr, 'description', ''),
                    "state": mr.state,
                    "source_branch": mr.source_branch,
                    "target_branch": mr.target_branch,
                    "author": {
                        "id": mr.author.get('id') if hasattr(mr, 'author') else None,
                        "name": mr.author.get('name') if hasattr(mr, 'author') else None,
                        "username": mr.author.get('username') if hasattr(mr, 'author') else None
                    },
                    "assignees": [
                        {
                            "id": assignee.get('id'),
                            "name": assignee.get('name'),
                            "username": assignee.get('username')
                        }
                        for assignee in getattr(mr, 'assignees', [])
                    ],
                    "reviewers": [
                        {
                            "id": reviewer.get('id'),
                            "name": reviewer.get('name'),
                            "username": reviewer.get('username')
                        }
                        for reviewer in getattr(mr, 'reviewers', [])
                    ],
                    "labels": getattr(mr, 'labels', []),
                    "draft": getattr(mr, 'draft', False),
                    "merged": getattr(mr, 'merged', False),
                    "created_at": getattr(mr, 'created_at', ''),
                    "updated_at": getattr(mr, 'updated_at', ''),
                    "merged_at": getattr(mr, 'merged_at', None),
                    "closed_at": getattr(mr, 'closed_at', None),
                    "web_url": mr.web_url,
                    "merge_status": getattr(mr, 'merge_status', ''),
                    "detailed_merge_status": getattr(mr, 'detailed_merge_status', '')
                }
                mr_list.append(mr_data)

            return {
                "success": True,
                "merge_requests": mr_list,
                "count": len(mr_list),
                "page": params.page,
                "per_page": params.per_page,
                "state_filter": params.state.value if params.state else 'opened'
            }

        except Exception as e:
            logger.error(f"Error listing merge requests: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def get_merge_request(params: GetMergeRequestSchema) -> Dict[str, Any]:
        """Obtener un merge request específico"""
        try:
            if params.merge_request_iid:
                mr = gitlab_client.get_merge_request(params.project_id, params.merge_request_iid)
            elif params.source_branch:
                # Buscar MR por branch source
                mrs = gitlab_client.list_merge_requests(
                    params.project_id, 
                    source_branch=params.source_branch,
                    state='opened'
                )
                if not mrs:
                    return {
                        "success": False,
                        "error": f"No open merge request found for branch '{params.source_branch}'"
                    }
                mr = mrs[0]  # Tomar el primero
            else:
                return {
                    "success": False,
                    "error": "Either merge_request_iid or source_branch must be provided"
                }

            mr_data = {
                "id": mr.id,
                "iid": mr.iid,
                "title": mr.title,
                "description": getattr(mr, 'description', ''),
                "state": mr.state,
                "source_branch": mr.source_branch,
                "target_branch": mr.target_branch,
                "author": {
                    "id": mr.author.get('id') if hasattr(mr, 'author') else None,
                    "name": mr.author.get('name') if hasattr(mr, 'author') else None,
                    "username": mr.author.get('username') if hasattr(mr, 'author') else None,
                    "avatar_url": mr.author.get('avatar_url') if hasattr(mr, 'author') else None
                },
                "assignees": [
                    {
                        "id": assignee.get('id'),
                        "name": assignee.get('name'),
                        "username": assignee.get('username'),
                        "avatar_url": assignee.get('avatar_url')
                    }
                    for assignee in getattr(mr, 'assignees', [])
                ],
                "reviewers": [
                    {
                        "id": reviewer.get('id'),
                        "name": reviewer.get('name'),
                        "username": reviewer.get('username'),
                        "avatar_url": reviewer.get('avatar_url')
                    }
                    for reviewer in getattr(mr, 'reviewers', [])
                ],
                "labels": getattr(mr, 'labels', []),
                "milestone": {
                    "id": mr.milestone.get('id') if hasattr(mr, 'milestone') and mr.milestone else None,
                    "title": mr.milestone.get('title') if hasattr(mr, 'milestone') and mr.milestone else None
                } if hasattr(mr, 'milestone') and mr.milestone else None,
                "draft": getattr(mr, 'draft', False),
                "merged": getattr(mr, 'merged', False),
                "created_at": getattr(mr, 'created_at', ''),
                "updated_at": getattr(mr, 'updated_at', ''),
                "merged_at": getattr(mr, 'merged_at', None),
                "closed_at": getattr(mr, 'closed_at', None),
                "web_url": mr.web_url,
                "merge_status": getattr(mr, 'merge_status', ''),
                "detailed_merge_status": getattr(mr, 'detailed_merge_status', ''),
                "merge_commit_sha": getattr(mr, 'merge_commit_sha', None),
                "squash": getattr(mr, 'squash', False),
                "should_remove_source_branch": getattr(mr, 'should_remove_source_branch', False),
                "force_remove_source_branch": getattr(mr, 'force_remove_source_branch', False),
                "changes_count": getattr(mr, 'changes_count', None),
                "user_notes_count": getattr(mr, 'user_notes_count', 0),
                "upvotes": getattr(mr, 'upvotes', 0),
                "downvotes": getattr(mr, 'downvotes', 0)
            }

            return {
                "success": True,
                "merge_request": mr_data
            }

        except Exception as e:
            logger.error(f"Error getting merge request: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def update_merge_request(params: Dict[str, Any]) -> Dict[str, Any]:
        """Actualizar un merge request"""
        try:
            project_id = params.get('project_id')
            mr_iid = params.get('merge_request_iid')

            if not project_id or not mr_iid:
                return {
                    "success": False,
                    "error": "project_id and merge_request_iid are required"
                }

            mr = gitlab_client.get_merge_request(project_id, int(mr_iid))

            # Actualizar campos según parámetros
            if 'title' in params:
                mr.title = params['title']
            if 'description' in params:
                mr.description = params['description']
            if 'target_branch' in params:
                mr.target_branch = params['target_branch']
            if 'assignee_ids' in params:
                mr.assignee_ids = params['assignee_ids']
            if 'reviewer_ids' in params:
                mr.reviewer_ids = params['reviewer_ids']
            if 'labels' in params:
                mr.labels = ','.join(params['labels']) if isinstance(params['labels'], list) else params['labels']
            if 'state_event' in params:
                mr.state_event = params['state_event']
            if 'remove_source_branch' in params:
                mr.remove_source_branch = params['remove_source_branch']
            if 'squash' in params:
                mr.squash = params['squash']
            if 'draft' in params:
                mr.draft = params['draft']

            mr.save()

            mr_data = {
                "id": mr.id,
                "iid": mr.iid,
                "title": mr.title,
                "description": getattr(mr, 'description', ''),
                "state": mr.state,
                "source_branch": mr.source_branch,
                "target_branch": mr.target_branch,
                "labels": getattr(mr, 'labels', []),
                "draft": getattr(mr, 'draft', False),
                "updated_at": getattr(mr, 'updated_at', ''),
                "web_url": mr.web_url
            }

            return {
                "success": True,
                "merge_request": mr_data,
                "message": f"Merge request '!{mr.iid}' updated successfully"
            }

        except Exception as e:
            logger.error(f"Error updating merge request: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def merge_merge_request(params: Dict[str, Any]) -> Dict[str, Any]:
        """Fusionar un merge request"""
        try:
            project_id = params.get('project_id')
            mr_iid = params.get('merge_request_iid')

            if not project_id or not mr_iid:
                return {
                    "success": False,
                    "error": "project_id and merge_request_iid are required"
                }

            mr = gitlab_client.get_merge_request(project_id, int(mr_iid))

            # Verificar que se pueda fusionar
            if mr.state != 'opened':
                return {
                    "success": False,
                    "error": f"Cannot merge - merge request is {mr.state}"
                }

            merge_params = {}

            if 'merge_commit_message' in params:
                merge_params['merge_commit_message'] = params['merge_commit_message']

            if 'squash_commit_message' in params:
                merge_params['squash_commit_message'] = params['squash_commit_message']

            if 'should_remove_source_branch' in params:
                merge_params['should_remove_source_branch'] = params['should_remove_source_branch']

            if 'squash' in params:
                merge_params['squash'] = params['squash']

            # Ejecutar merge
            result = mr.merge(**merge_params)

            return {
                "success": True,
                "merge_result": {
                    "id": result.get('id') if result else mr.id,
                    "iid": result.get('iid') if result else mr.iid,
                    "state": result.get('state') if result else 'merged',
                    "merged_at": result.get('merged_at') if result else None,
                    "merge_commit_sha": result.get('merge_commit_sha') if result else None
                },
                "message": f"Merge request '!{mr.iid}' merged successfully"
            }

        except Exception as e:
            logger.error(f"Error merging merge request: {e}")
            return {
                "success": False,
                "error": str(e)
            }
