"""
Herramientas para gestión de issues GitLab
"""
import logging
from typing import Dict, Any, List
from fastmcp import FastMCP
from schemas import *
from gitlab_client import GitLabClient
from config import GitLabConfig

logger = logging.getLogger(__name__)

def register_issues_tools(app: FastMCP, gitlab_client: GitLabClient, config: GitLabConfig):
    """Registra herramientas de gestión de issues"""

    @app.tool()
    def create_issue(params: CreateIssueSchema) -> Dict[str, Any]:
        """Crear una nueva issue"""
        try:
            issue_data = {
                'title': params.title,
                'description': params.description or '',
                'issue_type': params.issue_type or 'issue'
            }

            if params.assignee_ids:
                issue_data['assignee_ids'] = params.assignee_ids

            if params.labels:
                issue_data['labels'] = ','.join(params.labels)

            if params.milestone_id:
                issue_data['milestone_id'] = params.milestone_id

            issue = gitlab_client.create_issue(params.project_id, issue_data)

            issue_result = {
                "id": issue.id,
                "iid": issue.iid,
                "title": issue.title,
                "description": getattr(issue, 'description', ''),
                "state": issue.state,
                "author": {
                    "id": issue.author.get('id') if hasattr(issue, 'author') else None,
                    "name": issue.author.get('name') if hasattr(issue, 'author') else None,
                    "username": issue.author.get('username') if hasattr(issue, 'author') else None
                },
                "assignees": [
                    {
                        "id": assignee.get('id'),
                        "name": assignee.get('name'),
                        "username": assignee.get('username')
                    }
                    for assignee in getattr(issue, 'assignees', [])
                ],
                "labels": getattr(issue, 'labels', []),
                "milestone": {
                    "id": issue.milestone.get('id') if hasattr(issue, 'milestone') and issue.milestone else None,
                    "title": issue.milestone.get('title') if hasattr(issue, 'milestone') and issue.milestone else None
                } if hasattr(issue, 'milestone') and issue.milestone else None,
                "created_at": getattr(issue, 'created_at', ''),
                "updated_at": getattr(issue, 'updated_at', ''),
                "web_url": issue.web_url,
                "issue_type": getattr(issue, 'issue_type', 'issue')
            }

            return {
                "success": True,
                "issue": issue_result,
                "message": f"Issue '#{issue.iid} - {issue.title}' created successfully"
            }

        except Exception as e:
            logger.error(f"Error creating issue: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def list_issues(params: ListIssuesSchema) -> Dict[str, Any]:
        """Listar issues del proyecto"""
        try:
            issue_params = {
                'state': params.state.value if params.state else 'opened',
                'page': params.page,
                'per_page': params.per_page
            }

            if params.labels:
                issue_params['labels'] = ','.join(params.labels)

            if params.assignee_id:
                issue_params['assignee_id'] = params.assignee_id

            if params.author_id:
                issue_params['author_id'] = params.author_id

            if params.search:
                issue_params['search'] = params.search

            if params.created_after:
                issue_params['created_after'] = params.created_after

            if params.created_before:
                issue_params['created_before'] = params.created_before

            issues = gitlab_client.list_issues(params.project_id, **issue_params)

            issue_list = []
            for issue in issues:
                issue_data = {
                    "id": issue.id,
                    "iid": issue.iid,
                    "title": issue.title,
                    "description": getattr(issue, 'description', ''),
                    "state": issue.state,
                    "author": {
                        "id": issue.author.get('id') if hasattr(issue, 'author') else None,
                        "name": issue.author.get('name') if hasattr(issue, 'author') else None,
                        "username": issue.author.get('username') if hasattr(issue, 'author') else None
                    },
                    "assignees": [
                        {
                            "id": assignee.get('id'),
                            "name": assignee.get('name'),
                            "username": assignee.get('username')
                        }
                        for assignee in getattr(issue, 'assignees', [])
                    ],
                    "labels": getattr(issue, 'labels', []),
                    "milestone": {
                        "id": issue.milestone.get('id') if hasattr(issue, 'milestone') and issue.milestone else None,
                        "title": issue.milestone.get('title') if hasattr(issue, 'milestone') and issue.milestone else None
                    } if hasattr(issue, 'milestone') and issue.milestone else None,
                    "created_at": getattr(issue, 'created_at', ''),
                    "updated_at": getattr(issue, 'updated_at', ''),
                    "closed_at": getattr(issue, 'closed_at', None),
                    "web_url": issue.web_url,
                    "issue_type": getattr(issue, 'issue_type', 'issue'),
                    "confidential": getattr(issue, 'confidential', False),
                    "due_date": getattr(issue, 'due_date', None)
                }
                issue_list.append(issue_data)

            return {
                "success": True,
                "issues": issue_list,
                "count": len(issue_list),
                "page": params.page,
                "per_page": params.per_page,
                "state_filter": params.state.value if params.state else 'opened'
            }

        except Exception as e:
            logger.error(f"Error listing issues: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def get_issue(params: Dict[str, Any]) -> Dict[str, Any]:
        """Obtener una issue específica"""
        try:
            project_id = params.get('project_id')
            issue_iid = params.get('issue_iid')

            if not project_id or not issue_iid:
                return {
                    "success": False,
                    "error": "project_id and issue_iid are required"
                }

            issue = gitlab_client.get_issue(project_id, int(issue_iid))

            issue_data = {
                "id": issue.id,
                "iid": issue.iid,
                "title": issue.title,
                "description": getattr(issue, 'description', ''),
                "state": issue.state,
                "author": {
                    "id": issue.author.get('id') if hasattr(issue, 'author') else None,
                    "name": issue.author.get('name') if hasattr(issue, 'author') else None,
                    "username": issue.author.get('username') if hasattr(issue, 'author') else None,
                    "avatar_url": issue.author.get('avatar_url') if hasattr(issue, 'author') else None
                },
                "assignees": [
                    {
                        "id": assignee.get('id'),
                        "name": assignee.get('name'),
                        "username": assignee.get('username'),
                        "avatar_url": assignee.get('avatar_url')
                    }
                    for assignee in getattr(issue, 'assignees', [])
                ],
                "labels": getattr(issue, 'labels', []),
                "milestone": {
                    "id": issue.milestone.get('id') if hasattr(issue, 'milestone') and issue.milestone else None,
                    "title": issue.milestone.get('title') if hasattr(issue, 'milestone') and issue.milestone else None,
                    "description": issue.milestone.get('description') if hasattr(issue, 'milestone') and issue.milestone else None,
                    "state": issue.milestone.get('state') if hasattr(issue, 'milestone') and issue.milestone else None,
                    "due_date": issue.milestone.get('due_date') if hasattr(issue, 'milestone') and issue.milestone else None
                } if hasattr(issue, 'milestone') and issue.milestone else None,
                "created_at": getattr(issue, 'created_at', ''),
                "updated_at": getattr(issue, 'updated_at', ''),
                "closed_at": getattr(issue, 'closed_at', None),
                "web_url": issue.web_url,
                "issue_type": getattr(issue, 'issue_type', 'issue'),
                "confidential": getattr(issue, 'confidential', False),
                "due_date": getattr(issue, 'due_date', None),
                "weight": getattr(issue, 'weight', None),
                "user_notes_count": getattr(issue, 'user_notes_count', 0),
                "upvotes": getattr(issue, 'upvotes', 0),
                "downvotes": getattr(issue, 'downvotes', 0)
            }

            return {
                "success": True,
                "issue": issue_data
            }

        except Exception as e:
            logger.error(f"Error getting issue: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def update_issue(params: UpdateIssueSchema) -> Dict[str, Any]:
        """Actualizar una issue existente"""
        try:
            update_data = {}

            if params.title:
                update_data['title'] = params.title

            if params.description is not None:
                update_data['description'] = params.description

            if params.assignee_ids is not None:
                update_data['assignee_ids'] = params.assignee_ids

            if params.labels is not None:
                update_data['labels'] = ','.join(params.labels)

            if params.state_event:
                update_data['state_event'] = params.state_event

            if not update_data:
                return {
                    "success": False,
                    "error": "No update data provided"
                }

            issue = gitlab_client.update_issue(params.project_id, params.issue_iid, update_data)

            issue_data = {
                "id": issue.id,
                "iid": issue.iid,
                "title": issue.title,
                "description": getattr(issue, 'description', ''),
                "state": issue.state,
                "labels": getattr(issue, 'labels', []),
                "assignees": [
                    {
                        "id": assignee.get('id'),
                        "name": assignee.get('name'),
                        "username": assignee.get('username')
                    }
                    for assignee in getattr(issue, 'assignees', [])
                ],
                "updated_at": getattr(issue, 'updated_at', ''),
                "web_url": issue.web_url
            }

            return {
                "success": True,
                "issue": issue_data,
                "message": f"Issue '#{issue.iid}' updated successfully"
            }

        except Exception as e:
            logger.error(f"Error updating issue: {e}")
            return {
                "success": False,
                "error": str(e)
            }

    @app.tool()
    def delete_issue(params: Dict[str, Any]) -> Dict[str, Any]:
        """Eliminar una issue"""
        try:
            project_id = params.get('project_id')
            issue_iid = params.get('issue_iid')

            if not project_id or not issue_iid:
                return {
                    "success": False,
                    "error": "project_id and issue_iid are required"
                }

            issue = gitlab_client.get_issue(project_id, int(issue_iid))
            issue.delete()

            return {
                "success": True,
                "message": f"Issue '#{issue_iid}' deleted successfully"
            }

        except Exception as e:
            logger.error(f"Error deleting issue: {e}")
            return {
                "success": False,
                "error": str(e)
            }
